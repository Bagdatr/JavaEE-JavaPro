package kz.rakhimov.buildings_rest_ajax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuildingsRestAjaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
